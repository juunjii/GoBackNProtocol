# Do NOT modify this file.

from simulator import sim

# Run the simulator when using the Stop-and-Wait protocol.
sim.type = 'SNW'
sim.run()