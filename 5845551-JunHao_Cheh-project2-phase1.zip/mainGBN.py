# Do NOT modify this file.

from simulator import sim

# Run the simulator when using the Go-Back-N protocol.
sim.type = 'GBN'
sim.run()